import { useLayoutEffect, useRef, type RefObject } from "react";
import { createPortal } from "react-dom";
import {
  BALL_RADIUS,
  type BallSnapshot,
  PLAYERS,
  type PlayerId,
  SCENE_SCALE,
  WORLD_HEIGHT,
  WORLD_WIDTH,
} from "../game/types";
import { Ball } from "./Ball";

export function FlyingBall({
  ball,
  arenaRef,
  scoreRefs,
  onComplete,
}: {
  ball: BallSnapshot;
  arenaRef: RefObject<HTMLDivElement | null>;
  scoreRefs: RefObject<Record<PlayerId, HTMLDivElement | null>>;
  onComplete: (id: PlayerId) => void;
}) {
  const elementRef = useRef<HTMLDivElement | null>(null);
  const player = PLAYERS.find((item) => item.id === ball.id)!;

  useLayoutEffect(() => {
    const element = elementRef.current;
    const arena = arenaRef.current;
    const target = scoreRefs.current[ball.id];
    if (!element || !arena || !target) {
      onComplete(ball.id);
      return;
    }

    const sourceBox = arena.getBoundingClientRect();
    const targetBox = target.getBoundingClientRect();
    const size = sourceBox.width * ((BALL_RADIUS * 2) / WORLD_WIDTH) * SCENE_SCALE;
    const sceneX = 0.5 + (ball.x / WORLD_WIDTH - 0.5) * SCENE_SCALE;
    const sceneY = 0.4 + (ball.y / WORLD_HEIGHT - 0.4) * SCENE_SCALE;
    const startX = sourceBox.left + sourceBox.width * sceneX - size / 2;
    const startY = sourceBox.top + sourceBox.height * sceneY - size / 2;
    const endX = targetBox.left + targetBox.width / 2 - size / 2;
    const endY = targetBox.top + targetBox.height / 2 - size / 2;
    element.style.width = `${size}px`;
    element.style.height = `${size}px`;

    if (typeof element.animate !== "function") {
      const timer = window.setTimeout(() => onComplete(ball.id), 0);
      return () => window.clearTimeout(timer);
    }

    const animation = element.animate(
      [
        { transform: `translate(${startX}px, ${startY}px) scale(1)`, opacity: 1, offset: 0 },
        { transform: `translate(${startX}px, ${startY + size * 0.12}px) scale(.58)`, opacity: 1, offset: 0.16 },
        { transform: `translate(${startX}px, ${startY - size * 0.65}px) scale(.88)`, opacity: 1, offset: 0.38 },
        { transform: `translate(${endX}px, ${endY}px) scale(.35)`, opacity: 0, offset: 1 },
      ],
      { duration: 1350, easing: "cubic-bezier(.3,.02,.18,1)", fill: "forwards" },
    );
    animation.onfinish = () => onComplete(ball.id);
    return () => {
      animation.onfinish = null;
      animation.cancel();
    };
  }, [arenaRef, ball, onComplete, scoreRefs]);

  return createPortal(
    <div className="flying-ball" ref={elementRef}>
      <Ball player={player} />
    </div>,
    document.body,
  );
}