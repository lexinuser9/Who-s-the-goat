import type { Player } from "../game/types";

export function Ball({ player }: { player: Player }) {
  return (
    <div className={`ball ball--${player.color}`} aria-hidden="true">
      <span>{player.number}</span>
    </div>
  );
}