import { useRef, type CSSProperties } from "react";
import { Crown, Play, RotateCcw, Sparkles, Trophy, Volume2, VolumeX } from "lucide-react";
import { Ball } from "./components/Ball";
import { FlyingBall } from "./components/FlyingBall";
import { formatScore } from "./game/scoring";
import {
  BALL_RADIUS,
  type GamePhase,
  PLAYERS,
  type Player,
  type PlayerId,
  WORLD_HEIGHT,
  WORLD_WIDTH,
} from "./game/types";
import { useGame } from "./game/useGame";

function Laurel({ flipped = false }: { flipped?: boolean }) {
  return (
    <svg className={`laurel ${flipped ? "laurel--flipped" : ""}`} viewBox="0 0 58 88" aria-hidden="true">
      <path d="M50 82C24 69 13 43 15 10" fill="none" stroke="currentColor" strokeWidth="2.3" />
      <path d="M17 20C6 16 5 8 8 1c9 3 13 9 9 19ZM16 32C5 30 1 24 1 17c9 1 16 6 15 15ZM19 44C8 44 2 39 1 32c10-1 17 4 18 12ZM24 56C13 57 6 53 4 46c10-2 18 1 20 10ZM31 67C20 69 13 66 10 59c10-3 18-1 21 8ZM42 77C32 80 25 78 21 72c9-5 17-4 21 5ZM18 23c-1-9 3-16 10-19 2 9-1 16-10 19ZM19 36c1-10 6-15 14-17 0 9-4 15-14 17ZM23 49c2-9 8-14 16-14-2 9-7 14-16 14ZM29 61c3-9 10-12 18-11-3 9-9 13-18 11ZM37 72c5-8 12-10 19-7-4 8-11 10-19 7Z" fill="currentColor" />
    </svg>
  );
}

function PlayerCard({
  player,
  score,
  isWinner,
  pulse,
  scoreRef,
}: {
  player: Player;
  score: number;
  isWinner: boolean;
  pulse: boolean;
  scoreRef: (node: HTMLDivElement | null) => void;
}) {
  return (
    <article className={`player-card ${isWinner ? "player-card--winner" : ""}`} aria-label={`${player.fullName}, ${score} wins`}>
      <div className="player-name">{player.name}</div>
      <div className={`player-photo player-photo--${player.id}`}>
        <img src={player.photo} alt={player.fullName} />
        <div className="photo-shade" />
        <div className="photo-caption">
          <span>{player.country}</span>
          <span>NO. {player.number.padStart(2, "0")}</span>
        </div>
      </div>
      <div ref={scoreRef} className={`scoreboard ${pulse ? "scoreboard--pulse" : ""}`}>
        <Trophy className="score-trophy" fill="currentColor" strokeWidth={1.7} aria-hidden="true" />
        <span key={score} className={`score-digits ${pulse ? "score-digits--pulse" : ""}`}>
          {formatScore(score)}
        </span>
        <span className="score-label">WINS</span>
      </div>
    </article>
  );
}

function statusText(phase: GamePhase, winner: PlayerId | null) {
  const player = PLAYERS.find((item) => item.id === winner);
  switch (phase) {
    case "ROUND_STARTING":
      return "GET READY TO DROP";
    case "PLAYING":
      return "THE RACE IS ON";
    case "WINNER_DETECTED":
    case "WINNER_ANIMATION":
      return `${player?.name ?? "A LEGEND"} TAKES IT!`;
    case "ROUND_COMPLETE":
      return `${player?.name ?? "A LEGEND"} WINS THE ROUND!`;
    case "AUTO_START_DELAY":
      return `${player?.name ?? "A LEGEND"} WINS! NEXT ROUND SOON`;
    case "RESETTING":
      return "RESETTING THE ARENA";
    default:
      return "READY WHEN YOU ARE";
  }
}

export default function App() {
  const game = useGame();
  const arenaRef = useRef<HTMLDivElement | null>(null);
  const scoreRefs = useRef<Record<PlayerId, HTMLDivElement | null>>({
    ronaldo: null,
    neymar: null,
    messi: null,
  });
  const canStart = ["READY", "ROUND_COMPLETE", "AUTO_START_DELAY"].includes(game.phase);
  const isComplete = ["ROUND_COMPLETE", "AUTO_START_DELAY"].includes(game.phase);

  return (
    <div className="page">
      <div className="ambient ambient--left" aria-hidden="true" />
      <div className="ambient ambient--right" aria-hidden="true" />
      <main className="game-machine">
        <div className="machine-inner">
          <header className="game-header">
            <div className="topline">
              <span className="topline-copy"><Sparkles size={12} /> THE ULTIMATE FOOTBALL SHOWDOWN <Sparkles size={12} /></span>
              <button
                className="sound-button"
                type="button"
                onClick={game.toggleSound}
                aria-label={game.muted ? "Turn sound on" : "Mute sound"}
                aria-pressed={!game.muted}
                title={game.muted ? "Turn sound on" : "Mute sound"}
              >
                {game.muted ? <VolumeX size={17} /> : <Volume2 size={17} />}
                <span>{game.muted ? "SOUND OFF" : "SOUND ON"}</span>
              </button>
            </div>
            <div className="title-lockup">
              <Laurel />
              <div className="title-center">
                <Crown className="title-crown" fill="currentColor" strokeWidth={1.5} aria-hidden="true" />
                <h1><span>WHO'S THE</span> <strong>GOAT?</strong></h1>
              </div>
              <Laurel flipped />
            </div>
            <p className="tagline">THREE LEGENDS <i /> ONE DRAIN <i /> ONE WINNER</p>
          </header>

          <section className="score-section" aria-label="Player scoreboards">
            <div className="section-heading">
              <span><span className="heading-spark" /> THE LEGENDS</span>
              <span className="section-heading-right">THE RACE FOR GREATNESS</span>
            </div>
            <div className="player-grid">
              {PLAYERS.map((player) => (
                <PlayerCard
                  key={player.id}
                  player={player}
                  score={game.scores[player.id]}
                  isWinner={game.winner === player.id}
                  pulse={game.scorePulse === player.id}
                  scoreRef={(node) => { scoreRefs.current[player.id] = node; }}
                />
              ))}
            </div>
          </section>

          <section className="contenders" aria-label="The three player balls">
            <div className="contenders-label"><span /> THE CONTENDERS <span /></div>
            <div className="contender-tray">
              {PLAYERS.map((player) => (
                <div className="contender" key={player.id} aria-label={`${player.fullName}: ${player.color} ball, number ${player.number}`}>
                  <Ball player={player} />
                  <div className="contender-copy"><b>{player.name}</b><small>NO. {player.number.padStart(2, "0")}</small></div>
                </div>
              ))}
            </div>
          </section>

          <section className="arena-section" aria-label="The sink arena">
            <div className="arena-heading">
              <div className="arena-title"><span className="arena-title-mark" /> THE SINK <small>FIRST BALL IN THE DRAIN WINS</small></div>
              <div className={`arena-status ${game.phase === "PLAYING" ? "arena-status--live" : ""}`} role="status" aria-live="polite">
                <span />{statusText(game.phase, game.winner)}
              </div>
            </div>
            <div className="arena-stage" ref={arenaRef}>
              <img className="sink-image" src="/images/purple-sink.png" alt="A glossy purple sink with a central drain" draggable="false" />
              <div className={`simulation-layer ${game.fading ? "simulation-layer--fading" : ""}`}>
                {game.balls.map((ball) => {
                  const player = PLAYERS.find((item) => item.id === ball.id)!;
                  const style: CSSProperties = {
                    left: `${(ball.x / WORLD_WIDTH) * 100}%`,
                    top: `${(ball.y / WORLD_HEIGHT) * 100}%`,
                    width: `${((BALL_RADIUS * 2) / WORLD_WIDTH) * 100}%`,
                    transform: `translate(-50%, -50%) rotate(${ball.angle}rad)`,
                  };
                  return (
                    <div className="ball-position" key={ball.id} style={style}>
                      <Ball player={player} />
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="arena-footnote"><span /> {game.round > 0 ? `ROUND ${String(game.round).padStart(2, "0")}` : "LET THE LEGENDS ROLL"} <span /></div>
          </section>

          <div className="action-area">
            <button className="play-button" type="button" onClick={game.startRound} disabled={!canStart}>
              <span>{canStart ? (isComplete ? "PLAY AGAIN" : "LET'S GO") : "RACE IN PROGRESS"}</span>
              <span className="play-icon"><Play size={23} fill="currentColor" strokeWidth={1.5} /></span>
            </button>
            <p className="play-hint">{canStart ? "DROP THE BALLS. CROWN THE GOAT." : "SIT BACK AND WATCH THE RACE."}</p>
          </div>

          <div className="controls" aria-label="Game controls">
            <button className="control-button auto-control" type="button" onClick={game.toggleAutoStart} aria-pressed={game.autoStart}>
              <span className="control-copy"><b>AUTO START</b><small>{game.autoStart ? "ON" : "OFF"}</small></span>
              <span className={`toggle-track ${game.autoStart ? "toggle-track--on" : ""}`}><span /></span>
            </button>
            <div className="control-separator" />
            <button className="control-button reset-control" type="button" onClick={game.reset}>
              <RotateCcw size={20} strokeWidth={2.3} />
              <span className="control-copy"><b>RESET</b><small>START FRESH</small></span>
            </button>
          </div>
          <footer className="game-footer">
            <span>MADE FOR THE BEAUTIFUL GAME</span>
            <a href="/ATTRIBUTIONS.txt" target="_blank" rel="noreferrer">PHOTO CREDITS</a>
          </footer>
        </div>
      </main>
      {game.flyingBall && (
        <FlyingBall ball={game.flyingBall} arenaRef={arenaRef} scoreRefs={scoreRefs} onComplete={game.completeWinnerAnimation} />
      )}
    </div>
  );
}