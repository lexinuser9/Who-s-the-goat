import { Bodies, Body, Composite, Engine, Events, Query } from "matter-js";
import {
  BALL_RADIUS,
  type BallSnapshot,
  type PlayerId,
  WORLD_WIDTH,
} from "./types";

const FIXED_STEP = 1000 / 60;
const DRAIN_X = WORLD_WIDTH / 2;
const DRAIN_ENTRY_Y = 351;
const DRAIN_HALF_ENTRY = 28;

export interface PhysicsStep {
  balls: BallSnapshot[];
  winner: BallSnapshot | null;
  impact: number;
}

function wallBetween(x1: number, y1: number, x2: number, y2: number): Body {
  const length = Math.hypot(x2 - x1, y2 - y1);
  return Bodies.rectangle((x1 + x2) / 2, (y1 + y2) / 2, length + 5, 20, {
    isStatic: true,
    angle: Math.atan2(y2 - y1, x2 - x1),
    friction: 0.045,
    restitution: 0.42,
    label: "basin-wall",
  });
}

function shuffled<T>(items: T[]): T[] {
  const result = [...items];
  for (let index = result.length - 1; index > 0; index -= 1) {
    const other = Math.floor(Math.random() * (index + 1));
    [result[index], result[other]] = [result[other], result[index]];
  }
  return result;
}

/** A self-contained 2D cross-section of the basin, independent of React. */
export class SinkPhysics {
  private engine: Engine;
  private balls = new Map<PlayerId, Body>();
  private drain: Body;
  private plug: Body | null = null;
  private hasWinner = false;
  private impact = 0;

  constructor() {
    this.engine = Engine.create({ enableSleeping: false });
    this.engine.gravity.y = 1;
    this.engine.gravity.scale = 0.001;
    this.engine.positionIterations = 8;
    this.engine.velocityIterations = 8;

    const outline: [number, number, number, number][] = [
      [130, -380, 130, 220],
      [130, 220, 165, 287],
      [165, 287, 225, 330],
      [225, 330, 325, 359],
      [325, 359, 438, 377],
      [562, 377, 675, 359],
      [675, 359, 775, 330],
      [775, 330, 835, 287],
      [835, 287, 870, 220],
      [870, 220, 870, -380],
    ];

    this.drain = Bodies.rectangle(DRAIN_X, 385, 38, 14, {
      isStatic: true,
      isSensor: true,
      label: "drain-sensor",
    });
    Composite.add(this.engine.world, [
      ...outline.map((line) => wallBetween(...line)),
      this.drain,
    ]);

    Events.on(this.engine, "collisionStart", (event) => {
      for (const pair of event.pairs) {
        if (pair.bodyA.isSensor || pair.bodyB.isSensor) continue;
        if (!pair.bodyA.label.startsWith("ball:") && !pair.bodyB.label.startsWith("ball:")) continue;
        const relativeSpeed = Math.hypot(
          pair.bodyA.velocity.x - pair.bodyB.velocity.x,
          pair.bodyA.velocity.y - pair.bodyB.velocity.y,
        );
        this.impact = Math.max(this.impact, relativeSpeed);
      }
    });
  }

  startRound() {
    this.clearRound();
    this.hasWinner = false;
    const players = shuffled<PlayerId>(["ronaldo", "neymar", "messi"]);
    // Leave the space directly above the drain open so a race involves the
    // sloping basin rather than a free fall straight into the hole.
    const lanes = Math.random() < 0.5 ? [245, 385, 735] : [265, 615, 755];

    players.forEach((id, index) => {
      // The random initial conditions are not a winner selection: the bodies
      // still have to collide, roll and physically pass through the drain.
      const ball = Bodies.circle(
        lanes[index] + (Math.random() - 0.5) * 75,
        -85 - Math.random() * 135,
        BALL_RADIUS,
        {
          label: `ball:${id}`,
          restitution: 0.66,
          friction: 0.045,
          frictionStatic: 0.12,
          frictionAir: 0.0018,
          density: 0.002,
          slop: 0.04,
        },
      );
      Body.setVelocity(ball, { x: (Math.random() - 0.5) * 2.8, y: Math.random() * 0.6 });
      Body.setAngularVelocity(ball, (Math.random() - 0.5) * 0.07);
      this.balls.set(id, ball);
      Composite.add(this.engine.world, ball);
    });
  }

  step(delta = FIXED_STEP): PhysicsStep {
    const previous = new Map<PlayerId, { x: number; y: number }>();
    for (const [id, ball] of this.balls) {
      previous.set(id, { ...ball.position });
      if (!this.hasWinner && ball.position.y > 125) {
        const dx = DRAIN_X - ball.position.x;
        const dy = 370 - ball.position.y;
        const distance = Math.hypot(dx, dy);
        const influence = Math.max(0, 1 - distance / 600);
        const lateBoost = 1 + Math.min(1.5, Math.max(0, this.engine.timing.timestamp - 5000) / 9000);
        const pull = ball.mass * (0.00013 + 0.00035 * influence) * lateBoost;
        const direction = Math.hypot(dx, dy * 0.55) || 1;
        Body.applyForce(ball, ball.position, {
          x: (dx / direction) * pull,
          y: Math.max(0, dy / direction) * pull * 0.38,
        });
      }
    }

    Engine.update(this.engine, delta);
    let winner: BallSnapshot | null = null;

    if (!this.hasWinner) {
      const candidates = [...this.balls.entries()]
        .filter(([, ball]) =>
          Math.abs(ball.position.x - DRAIN_X) < DRAIN_HALF_ENTRY &&
          ball.position.y >= DRAIN_ENTRY_Y &&
          Query.collides(ball, [this.drain]).length > 0,
        )
        .map(([id, ball]) => {
          const old = previous.get(id)!;
          const travel = ball.position.y - old.y;
          const entryTime = travel > 0 ? Math.max(0, (DRAIN_ENTRY_Y - old.y) / travel) : 0;
          return { id, ball, entryTime };
        })
        .sort((a, b) => a.entryTime - b.entryTime);

      if (candidates.length) {
        const { id, ball } = candidates[0];
        winner = this.snapshot(id, ball);
        this.hasWinner = true;
        Composite.remove(this.engine.world, ball);
        this.balls.delete(id);

        // Once the winner is captured, the remaining balls settle in the bowl
        // without being able to register a second winner or fall out of view.
        this.plug = Bodies.rectangle(DRAIN_X, 389, 130, 18, {
          isStatic: true,
          label: "closed-drain",
          friction: 0.08,
          restitution: 0.25,
        });
        Composite.add(this.engine.world, this.plug);
      }
    }

    const impact = this.impact;
    this.impact = 0;
    return { balls: this.getBalls(), winner, impact };
  }

  getBalls(): BallSnapshot[] {
    return [...this.balls.entries()].map(([id, ball]) => this.snapshot(id, ball));
  }

  clearRound() {
    for (const ball of this.balls.values()) Composite.remove(this.engine.world, ball);
    this.balls.clear();
    if (this.plug) Composite.remove(this.engine.world, this.plug);
    this.plug = null;
    this.impact = 0;
    this.engine.timing.timestamp = 0;
    Engine.clear(this.engine);
  }

  destroy() {
    this.clearRound();
    Events.off(this.engine, "collisionStart");
    Composite.clear(this.engine.world, false, true);
    Engine.clear(this.engine);
  }

  private snapshot(id: PlayerId, ball: Body): BallSnapshot {
    return { id, x: ball.position.x, y: ball.position.y, angle: ball.angle };
  }
}

export { FIXED_STEP };