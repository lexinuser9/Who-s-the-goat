export type PlayerId = "ronaldo" | "neymar" | "messi";

export type GamePhase =
  | "READY"
  | "ROUND_STARTING"
  | "PLAYING"
  | "WINNER_DETECTED"
  | "WINNER_ANIMATION"
  | "ROUND_COMPLETE"
  | "AUTO_START_DELAY"
  | "RESETTING";

export interface Player {
  id: PlayerId;
  name: string;
  fullName: string;
  country: string;
  number: string;
  color: "yellow" | "blue" | "red";
  photo: string;
}

export interface BallSnapshot {
  id: PlayerId;
  x: number;
  y: number;
  angle: number;
}

export type Scores = Record<PlayerId, number>;

export const PLAYERS: Player[] = [
  {
    id: "ronaldo",
    name: "RONALDO",
    fullName: "Cristiano Ronaldo",
    country: "PORTUGAL",
    number: "7",
    color: "red",
    photo: "/images/ronaldo-2018.jpg",
  },
  {
    id: "neymar",
    name: "NEYMAR JR.",
    fullName: "Neymar Jr.",
    country: "BRAZIL",
    number: "10",
    color: "yellow",
    photo: "/images/neymar.jpg",
  },
  {
    id: "messi",
    name: "MESSI",
    fullName: "Lionel Messi",
    country: "ARGENTINA",
    number: "10",
    color: "blue",
    photo: "/images/messi.jpg",
  },
];

export const INITIAL_SCORES: Scores = { ronaldo: 0, neymar: 0, messi: 0 };

// Change this value to adjust the pause between automatic rounds.
export const AUTO_START_DELAY_MS = 2400;

export const WORLD_WIDTH = 1000;
export const WORLD_HEIGHT = 562.5;
export const BALL_RADIUS = 46;
export const SCENE_SCALE = 1.1;

export const PREVIEW_BALLS: BallSnapshot[] = [
  { id: "ronaldo", x: 270, y: 320, angle: -0.12 },
  { id: "neymar", x: 500, y: 300, angle: 0.08 },
  { id: "messi", x: 730, y: 320, angle: 0.1 },
];