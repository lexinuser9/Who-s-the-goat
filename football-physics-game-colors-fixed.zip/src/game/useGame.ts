import { useCallback, useEffect, useRef, useState } from "react";
import { GameAudio } from "./audio";
import { FIXED_STEP, SinkPhysics } from "./physics";
import { incrementScore } from "./scoring";
import {
  AUTO_START_DELAY_MS,
  type BallSnapshot,
  type GamePhase,
  INITIAL_SCORES,
  type PlayerId,
  PREVIEW_BALLS,
  type Scores,
} from "./types";
import { notifyWinnerVideo } from "./winnerVideo";

export function useGame() {
  const [phase, setPhase] = useState<GamePhase>("READY");
  const [balls, setBalls] = useState<BallSnapshot[]>(PREVIEW_BALLS);
  const [fading, setFading] = useState(false);
  const [scores, setScores] = useState<Scores>({ ...INITIAL_SCORES });
  const [winner, setWinner] = useState<PlayerId | null>(null);
  const [flyingBall, setFlyingBall] = useState<BallSnapshot | null>(null);
  const [scorePulse, setScorePulse] = useState<PlayerId | null>(null);
  const [autoStart, setAutoStart] = useState(false);
  const [muted, setMuted] = useState(true);
  const [round, setRound] = useState(0);

  const phaseRef = useRef<GamePhase>("READY");
  const ballsRef = useRef<BallSnapshot[]>(PREVIEW_BALLS);
  const autoRef = useRef(false);
  const mutedRef = useRef(true);
  const winnerRef = useRef<PlayerId | null>(null);
  const physicsRef = useRef<SinkPhysics | null>(null);
  const audioRef = useRef<GameAudio | null>(null);
  const frameRef = useRef<number | null>(null);
  const timersRef = useRef(new Set<number>());
  const autoTimerRef = useRef<number | null>(null);
  const startRoundRef = useRef<() => void>(() => undefined);

  const changePhase = useCallback((next: GamePhase) => {
    phaseRef.current = next;
    setPhase(next);
  }, []);

  const updateBalls = useCallback((next: BallSnapshot[]) => {
    ballsRef.current = next;
    setBalls(next);
  }, []);

  const schedule = useCallback((callback: () => void, delay: number) => {
    const timer = window.setTimeout(() => {
      timersRef.current.delete(timer);
      callback();
    }, delay);
    timersRef.current.add(timer);
    return timer;
  }, []);

  const cancelAutoTimer = useCallback(() => {
    if (autoTimerRef.current !== null) {
      window.clearTimeout(autoTimerRef.current);
      timersRef.current.delete(autoTimerRef.current);
      autoTimerRef.current = null;
    }
  }, []);

  const clearTimers = useCallback(() => {
    timersRef.current.forEach((timer) => window.clearTimeout(timer));
    timersRef.current.clear();
    autoTimerRef.current = null;
  }, []);

  const stopLoop = useCallback(() => {
    if (frameRef.current !== null) window.cancelAnimationFrame(frameRef.current);
    frameRef.current = null;
  }, []);

  useEffect(() => {
    const physics = new SinkPhysics();
    const audio = new GameAudio();
    physicsRef.current = physics;
    audioRef.current = audio;

    return () => {
      stopLoop();
      clearTimers();
      physics.destroy();
      audio.destroy();
      physicsRef.current = null;
      audioRef.current = null;
    };
  }, [clearTimers, stopLoop]);

  const scheduleAutoRound = useCallback(() => {
    if (!autoRef.current || phaseRef.current !== "ROUND_COMPLETE") return;
    cancelAutoTimer();
    changePhase("AUTO_START_DELAY");
    autoTimerRef.current = schedule(() => {
      autoTimerRef.current = null;
      if (autoRef.current && phaseRef.current === "AUTO_START_DELAY") startRoundRef.current();
    }, AUTO_START_DELAY_MS);
  }, [cancelAutoTimer, changePhase, schedule]);

  const handleWinner = useCallback(
    (ball: BallSnapshot) => {
      if (phaseRef.current !== "PLAYING") return;
      winnerRef.current = ball.id;
      changePhase("WINNER_DETECTED");
      setWinner(ball.id);
      setFlyingBall(ball);
      audioRef.current?.play("drain");
      notifyWinnerVideo(ball.id);
      schedule(() => {
        if (phaseRef.current === "WINNER_DETECTED") changePhase("WINNER_ANIMATION");
      }, 100);
    },
    [changePhase, schedule],
  );

  const runLoop = useCallback(() => {
    stopLoop();
    let last = performance.now();
    let accumulator = 0;

    const tick = (now: number) => {
      const physics = physicsRef.current;
      if (!physics || !["PLAYING", "WINNER_DETECTED", "WINNER_ANIMATION"].includes(phaseRef.current)) {
        frameRef.current = null;
        return;
      }
      accumulator += Math.min(now - last, 80);
      last = now;
      let latest: ReturnType<SinkPhysics["step"]> | null = null;
      let steps = 0;
      while (accumulator >= FIXED_STEP && steps < 5) {
        latest = physics.step();
        if (latest.impact) audioRef.current?.play("impact", latest.impact);
        if (latest.winner) handleWinner(latest.winner);
        accumulator -= FIXED_STEP;
        steps += 1;
      }
      if (latest) updateBalls(latest.balls);
      frameRef.current = window.requestAnimationFrame(tick);
    };

    frameRef.current = window.requestAnimationFrame(tick);
  }, [handleWinner, stopLoop, updateBalls]);

  const startRound = useCallback(() => {
    if (!["READY", "ROUND_COMPLETE", "AUTO_START_DELAY"].includes(phaseRef.current)) return;
    cancelAutoTimer();
    stopLoop();
    audioRef.current?.play("click");
    winnerRef.current = null;
    setWinner(null);
    setFlyingBall(null);
    setScorePulse(null);
    changePhase("ROUND_STARTING");
    setFading(true);

    schedule(() => {
      const physics = physicsRef.current;
      if (!physics || phaseRef.current !== "ROUND_STARTING") return;
      physics.startRound();
      updateBalls(physics.getBalls());
      setFading(false);
      setRound((current) => current + 1);
      changePhase("PLAYING");
      audioRef.current?.play("drop");
      runLoop();
    }, ballsRef.current.length ? 480 : 180);
  }, [cancelAutoTimer, changePhase, runLoop, schedule, stopLoop, updateBalls]);

  startRoundRef.current = startRound;

  const completeWinnerAnimation = useCallback(
    (id: PlayerId) => {
      if (winnerRef.current !== id || !["WINNER_DETECTED", "WINNER_ANIMATION"].includes(phaseRef.current)) return;
      stopLoop();
      if (physicsRef.current) updateBalls(physicsRef.current.getBalls());
      setFlyingBall(null);
      setScores((current) => incrementScore(current, id));
      setScorePulse(id);
      audioRef.current?.play("win");
      changePhase("ROUND_COMPLETE");
      schedule(() => setScorePulse(null), 1000);
      scheduleAutoRound();
    },
    [changePhase, schedule, scheduleAutoRound, stopLoop, updateBalls],
  );

  const toggleAutoStart = useCallback(() => {
    const next = !autoRef.current;
    autoRef.current = next;
    setAutoStart(next);
    audioRef.current?.play("click");
    if (!next) {
      cancelAutoTimer();
      if (phaseRef.current === "AUTO_START_DELAY") changePhase("ROUND_COMPLETE");
    } else if (phaseRef.current === "ROUND_COMPLETE") {
      scheduleAutoRound();
    }
  }, [cancelAutoTimer, changePhase, scheduleAutoRound]);

  const toggleSound = useCallback(() => {
    const next = !mutedRef.current;
    mutedRef.current = next;
    setMuted(next);
    audioRef.current?.setMuted(next);
    if (!next) audioRef.current?.play("click");
  }, []);

  const reset = useCallback(() => {
    audioRef.current?.play("click");
    changePhase("RESETTING");
    clearTimers();
    stopLoop();
    physicsRef.current?.clearRound();
    winnerRef.current = null;
    autoRef.current = false;
    setAutoStart(false);
    setWinner(null);
    setFlyingBall(null);
    setScorePulse(null);
    setScores({ ...INITIAL_SCORES });
    setFading(false);
    setRound(0);
    updateBalls([]);
    schedule(() => {
      if (phaseRef.current === "RESETTING") changePhase("READY");
    }, 120);
  }, [changePhase, clearTimers, schedule, stopLoop, updateBalls]);

  return {
    phase,
    balls,
    fading,
    scores,
    winner,
    flyingBall,
    scorePulse,
    autoStart,
    muted,
    round,
    startRound,
    completeWinnerAnimation,
    toggleAutoStart,
    toggleSound,
    reset,
  };
}