type SoundName = "click" | "drop" | "impact" | "drain" | "win";

/** Tiny synthesized sounds avoid downloads and stay entirely optional. */
export class GameAudio {
  private context: AudioContext | null = null;
  private muted = true;
  private lastImpact = 0;

  setMuted(muted: boolean) {
    this.muted = muted;
    if (!muted) this.unlock();
  }

  unlock() {
    if (this.muted) return;
    try {
      this.context ??= new AudioContext();
      if (this.context.state === "suspended") void this.context.resume();
    } catch {
      // The game remains playable when Web Audio is unavailable.
    }
  }

  play(name: SoundName, strength = 1) {
    if (this.muted) return;
    this.unlock();
    const context = this.context;
    if (!context || context.state !== "running") return;
    const now = context.currentTime;

    if (name === "impact") {
      if (now - this.lastImpact < 0.11 || strength < 1.8) return;
      this.lastImpact = now;
      this.tone(115 + Math.min(strength * 10, 130), 60, 0.09, Math.min(0.11, strength / 110), "sine");
    } else if (name === "drop") {
      this.tone(390, 180, 0.18, 0.07, "sine");
    } else if (name === "drain") {
      this.tone(280, 70, 0.36, 0.08, "sine");
    } else if (name === "click") {
      this.tone(620, 480, 0.055, 0.04, "triangle");
    } else {
      [523, 659, 784, 1047].forEach((frequency, index) => {
        this.tone(frequency, frequency * 1.02, 0.19, 0.055, "triangle", index * 0.09);
      });
    }
  }

  destroy() {
    if (this.context && this.context.state !== "closed") void this.context.close();
    this.context = null;
  }

  private tone(
    start: number,
    end: number,
    duration: number,
    volume: number,
    type: OscillatorType,
    delay = 0,
  ) {
    const context = this.context;
    if (!context) return;
    const at = context.currentTime + delay;
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(start, at);
    oscillator.frequency.exponentialRampToValueAtTime(end, at + duration);
    gain.gain.setValueAtTime(0.0001, at);
    gain.gain.exponentialRampToValueAtTime(volume, at + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, at + duration);
    oscillator.connect(gain);
    gain.connect(context.destination);
    oscillator.start(at);
    oscillator.stop(at + duration + 0.02);
  }
}