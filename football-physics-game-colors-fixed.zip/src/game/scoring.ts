import type { PlayerId, Scores } from "./types";

export function incrementScore(scores: Scores, winner: PlayerId): Scores {
  return { ...scores, [winner]: Math.min(999, scores[winner] + 1) };
}

export function formatScore(score: number): string {
  return String(Math.min(999, Math.max(0, Math.floor(score)))).padStart(3, "0");
}