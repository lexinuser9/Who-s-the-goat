import type { PlayerId } from "./types";

// Add one video URL per player here when the winner videos are ready.
export const WINNER_VIDEO_SOURCES: Record<PlayerId, string | null> = {
  ronaldo: null,
  neymar: null,
  messi: null,
};

export function notifyWinnerVideo(playerId: PlayerId) {
  window.dispatchEvent(
    new CustomEvent("goat:winner", {
      detail: { playerId, videoSource: WINNER_VIDEO_SOURCES[playerId] },
    }),
  );
}