# Who's the GOAT?

A mobile-first football arcade game. The balls are Matter.js bodies; the sloped basin, drain sensor, suction and ball collisions determine each winner.

## Run

```sh
npm install
npm run dev
```

Sound starts muted and can be enabled from the top-right control. Auto Start can be toggled at any time. Reset stops the current race, cancels pending rounds and clears the scores.

## Customize

- Change `AUTO_START_DELAY_MS` in `src/game/types.ts` to adjust the pause between automatic rounds.
- `src/game/winnerVideo.ts` contains one placeholder source per player and emits a `goat:winner` event with the winning player ID. No video playback is implemented yet.
- Player image credits are in `public/ATTRIBUTIONS.txt`.

## Checks

```sh
npm run build
node tests/physics-check.mjs
# With the development server running and Playwright Chromium installed:
npx playwright install chromium
node tests/browser-check.mjs
```