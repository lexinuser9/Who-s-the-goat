import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { build } from "esbuild";

const require = createRequire(import.meta.url);
const { Composite } = require("matter-js");

async function loadTypeScript(path) {
  const result = await build({
    entryPoints: [path],
    bundle: true,
    platform: "node",
    format: "cjs",
    write: false,
  });
  const module = { exports: {} };
  new Function("require", "module", "exports", result.outputFiles[0].text)(require, module, module.exports);
  return module.exports;
}

const { SinkPhysics } = await loadTypeScript("src/game/physics.ts");
const { incrementScore, formatScore } = await loadTypeScript("src/game/scoring.ts");
const simulation = new SinkPhysics();
const wins = { ronaldo: 0, neymar: 0, messi: 0 };

for (let round = 0; round < 250; round += 1) {
  simulation.startRound();
  assert.equal(simulation.getBalls().length, 3);
  assert.equal(Composite.allBodies(simulation.engine.world).length, 14);
  let winner = null;
  for (let frame = 0; frame < 1800 && !winner; frame += 1) {
    winner = simulation.step().winner;
  }
  assert.ok(winner, `Round ${round + 1} did not reach the drain`);
  wins[winner.id] += 1;
  assert.equal(simulation.getBalls().length, 2);
  for (let frame = 0; frame < 90; frame += 1) {
    assert.equal(simulation.step().winner, null, "A round registered two winners");
  }
}

simulation.clearRound();
assert.equal(Composite.allBodies(simulation.engine.world).length, 11, "Physics objects leaked between rounds");
simulation.destroy();
assert.ok(Object.values(wins).every((count) => count > 0));
assert.equal(formatScore(0), "000");
assert.equal(formatScore(3), "003");
assert.equal(formatScore(1000), "999");
assert.deepEqual(incrementScore({ ronaldo: 999, neymar: 0, messi: 0 }, "ronaldo"), {
  ronaldo: 999,
  neymar: 0,
  messi: 0,
});
console.log("250 physics races passed:", wins);