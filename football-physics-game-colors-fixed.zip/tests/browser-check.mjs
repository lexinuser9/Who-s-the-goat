import assert from "node:assert/strict";
import { chromium } from "playwright";

const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ viewport: { width: 390, height: 693 } });
const errors = [];
page.on("pageerror", (error) => errors.push(error.message));

try {
  await page.goto(process.env.GAME_URL || "http://127.0.0.1:5173/", { waitUntil: "networkidle" });
  await page.evaluate(() => {
    window.testWinners = [];
    window.addEventListener("goat:winner", (event) => window.testWinners.push(event.detail.playerId));
  });
  const scores = () => page.locator(".score-digits").allTextContents();
  const total = async () => (await scores()).reduce((sum, value) => sum + Number(value), 0);
  const waitForTotal = (target) => page.waitForFunction(
    (value) => [...document.querySelectorAll(".score-digits")].reduce((sum, item) => sum + Number(item.textContent), 0) >= value,
    target,
    { timeout: 25000 },
  );

  assert.deepEqual(await scores(), ["000", "000", "000"]);
  assert.equal(await page.locator(".contender-tray .ball").count(), 3);
  assert.equal(await page.locator(".ball-position").count(), 3);
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth), 390);

  await page.getByRole("button", { name: "Turn sound on" }).click();
  assert.equal(await page.getByRole("button", { name: "Mute sound" }).getAttribute("aria-pressed"), "true");
  await page.getByRole("button", { name: "Mute sound" }).click();
  await page.getByRole("button", { name: /LET'S GO/ }).click();
  assert.equal(await page.locator(".play-button").isDisabled(), true);
  await waitForTotal(1);
  assert.equal(await page.locator(".ball-position").count(), 2);
  await page.waitForTimeout(2800);
  assert.equal(await total(), 1, "Manual mode unexpectedly started another round");

  await page.getByRole("button", { name: /AUTO START/ }).click();
  await waitForTotal(2);
  await page.getByRole("button", { name: /AUTO START/ }).click();
  await page.waitForTimeout(3000);
  assert.equal(await total(), 2, "Turning auto start off did not cancel the next round");
  assert.equal(await page.evaluate(() => window.testWinners.length), 2);

  await page.getByRole("button", { name: /PLAY AGAIN/ }).click();
  await page.waitForTimeout(700);
  await page.getByRole("button", { name: /RESET/ }).click();
  await page.waitForTimeout(2000);
  assert.deepEqual(await scores(), ["000", "000", "000"]);
  assert.equal(await page.locator(".ball-position").count(), 0);
  assert.equal(await page.getByRole("button", { name: /AUTO START/ }).getAttribute("aria-pressed"), "false");
  assert.match(await page.locator(".arena-status").innerText(), /READY/);
  assert.deepEqual(errors, []);
  console.log("Browser round, auto-start, sound and reset checks passed.");
} finally {
  await browser.close();
}